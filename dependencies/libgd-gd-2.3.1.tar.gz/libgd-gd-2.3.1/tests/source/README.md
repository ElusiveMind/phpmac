These are tests/lints for the source code itself.
They aren't included in the default `make check` so they aren't run against
releases, but we run them against Github PRs in Travis.
